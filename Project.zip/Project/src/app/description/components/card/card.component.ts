import { Component, Input } from '@angular/core';
import { Description } from '../../model/description.entity';

@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrl: './card.component.css',
})
export class CardComponent {
  @Input() data: Description = new Description();
}
