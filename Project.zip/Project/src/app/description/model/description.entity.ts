export class Description {
  product_name: string;
  product_description: string;
  model: string;
  price: number;
  manufacturer: string;

  constructor(
    product_name = '',
    product_description = '',
    model = '',
    price = 0,
    manufacturer = ''
  ) {
    this.product_name = product_name;
    this.product_description = product_description;
    this.model = model;
    this.price = price;
    this.manufacturer = manufacturer;
  }
}
