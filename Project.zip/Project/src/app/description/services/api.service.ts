import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class ApiService {
  baseUrl = 'http://localhost:3000/description';
  constructor(private http: HttpClient) {}

  getUrl() {
    return this.http.get(this.baseUrl);
  }
}
