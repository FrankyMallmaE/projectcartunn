import { Component, OnInit } from '@angular/core';
import { ApiService } from './description/services/api.service';
import { Description } from './description/model/description.entity';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent implements OnInit {
  title = 'Project';
  data: Array<Description> = [];

  constructor(private Api: ApiService) {}

  ngOnInit() {
    this.getData();
  }

  getData(): void {
    this.Api.getUrl().subscribe((data: any) => {
      this.data = data;
      console.log(data);
    });
  }
}
